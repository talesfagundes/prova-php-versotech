<h1>Editar Usuario</h1>
<?php
	$sql = "SELECT * FROM users WHERE id=".$_REQUEST["id"];

	$res = $conn->query($sql);
	$row = $res->fetch_object();
?>
<form action="?page=save-user" method="POST">
	<input type="hidden" name="acao" value="update-user">
	<input type="hidden" name="id" value="<?php print $row->id; ?>">

	<div class="mb-3">
		<label>Name</label>
		<input type="text" name="name" value="<?php print $row->name; ?>" class="form-control">
	</div>
	<div class="mb-3">
		<label>E-mail</label>
		<input type="text" name="email" value="<?php print $row->email; ?>" class="form-control">
	</div>
	
	<div class="mb-3">
		<button type="submit" class="btn btn-primary">Editar</button>
	</div>
</form>

<button class= 'btn btn-danger' onclick= "location.href='?page=list'"  >Voltar</button>