<?php
	switch ($_REQUEST["acao"]) {

		case 'create-user':
			$name = $_POST['name'];
			$email = $_POST['email'];

			if (!empty($name) && !empty($email)){
				$sql = "INSERT INTO users (name, email) VALUES ('{$name}', '{$email}')";

				$res = $conn->query($sql);

				if($res==true){
					print "<script>alert('Criado com sucesso');</script>";
					print "<script>location.href='?page=list';</script>";
				}else{
					print "<script>alert('Não foi possível criar.');</script>";
					print "<script>location.href='?page=list';</script>";
				}
		}else{print "<script>alert('Todos os campos devem ser preenchidos.');</script>";
			  print "<script>location.href='?page=new-user';</script>";}
			break;
		

		case 'update-user':
			$name = $_POST['name'];
			$email = $_POST['email'];

			$sql = "UPDATE users SET name='{$name}', email='{$email}' WHERE id=".$_REQUEST['id'];

			$res = $conn->query($sql);

			if($res==true){
				print "<script>alert('Editado com sucesso');</script>";
				print "<script>location.href='?page=list';</script>";
			}else{
				print "<script>alert('Não foi possível editar');</script>";
				print "<script>location.href='?page=list';</script>";
			}
			break;

		case 'delete-user':
			$sql = "DELETE FROM users WHERE id= ".$_REQUEST["id"];

			$res = $conn->query($sql);

			if($res==true){
				print "<script>alert();</script>";
				print "<script>location.href='?page=list';</script>";
			}else{
				print "<script>alert('Não foi possível excluir');</script>";
				print "<script>location.href='?page=list';</script>";
			}


			break;
			}
		
		
	
