<h1>Editar Usuario</h1>
<form action="?page=save-user" method="POST">
	<input type="hidden" name="acao" value="create-user">
	<div class="mb-3">
		<label>Name</label>
		<input type="text" name="name"  class="form-control">
	</div>
	<div class="mb-3">
		<label>E-mail</label>
		<input type="text" name="email"  class="form-control">
	</div>
	
	<div class="mb-3">
		<button type="submit" class="btn btn-primary">Criar</button>
	</div>


</form>

<button class= 'btn btn-danger' onclick= "location.href='?page=list'"  >Voltar</button>

