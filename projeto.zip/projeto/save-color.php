<?php
	switch ($_REQUEST["acao"]){

		case 'create-color':
			$name = $_POST['name'];
			
			if (!empty($name)){
			$sql = "INSERT INTO colors (name) VALUES ('{$name}')";

			$res = $conn->query($sql);

			if($res==true){
				print "<script>alert('Criado com sucesso');</script>";
				print "<script>location.href='?page=list';</script>";
			}else{
				print "<script>alert('Não foi possível criar.');</script>";
				print "<script>location.href='?page=list';</script>";
			}
		}else{print "<script>alert('Todos os campos devem ser preenchidos.');</script>";
			  print "<script>location.href='?page=new-color';</script>";}
			break;

		case 'update-color':
			$name = $_POST['name'];


			$sql = "UPDATE colors SET name='{$name}' WHERE id=".$_REQUEST['id'];

			$res = $conn->query($sql);

			if($res==true){
				print "<script>alert('Editado com sucesso');</script>";
				print "<script>location.href='?page=list';</script>";
			}else{
				print "<script>alert('Não foi possível editar');</script>";
				print "<script>location.href='?page=list';</script>";
			}
			break;

		case 'delete-color':
			$sql = "DELETE FROM colors WHERE id=".$_REQUEST["id"];

			
			$res = $conn->query($sql);

			if($res==true){
				print "<script>alert('$sql');</script>";
				print "<script>location.href='?page=list';</script>";
			}else{
				print "<script>alert('Não foi possível excluir');</script>";
				print "<script>location.href='?page=list';</script>";
			}
			break;
			}
		
		
	
