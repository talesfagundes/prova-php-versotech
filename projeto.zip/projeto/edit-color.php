<h1>Editar Cor</h1>
<?php
	$sql = "SELECT * FROM colors WHERE id=".$_REQUEST["id"];

	$res = $conn->query($sql);
	$row = $res->fetch_object();
?>

<form action="?page=save-color" method="POST">
	<input type="hidden" name="acao" value="update-color">
	<input type="hidden" name="id" value="<?php print $row->id; ?>">

	<div class="mb-3">
		<label>Name</label>
		<input type="text" name="name" value="<?php print $row->name; ?>" class="form-control">
	</div>
	
	<div class="mb-3">
		<button type="submit" class="btn btn-primary">Editar</button>
	</div>

</form>

<button class= 'btn btn-danger' onclick= "location.href='?page=list'"  >Voltar</button>