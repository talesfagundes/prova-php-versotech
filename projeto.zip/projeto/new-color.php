<h1>Editar Cor</h1>

<form action="?page=save-color" method="POST">
	<input type="hidden" name="acao" value="create-color">
	<div class="mb-3">
		<label>Name</label>
		<input type="text" name="name"  class="form-control">
	</div>
	
	<div class="mb-3">
		<button type="submit" class="btn btn-primary">Criar</button>
	</div>
</form>

<button class= 'btn btn-danger' onclick= "location.href='?page=list'"  >Voltar</button>