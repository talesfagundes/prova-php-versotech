<?php 
    $sql = "SELECT * FROM colors";

    $res = $conn->query($sql);

    $userid = $_GET["id"];

    $sql = "SELECT color_id FROM user_colors
            WHERE user_id = $userid ";

    $res2 = $conn->query($sql);
    $vinculados = array();

    while ($row = $res2->fetch_object()) {
    	
        array_push($vinculados, $row->color_id);
    }

    

    $qtd = $res->num_rows;

    if($qtd > 0){
        print"<div class=\"mb-3\">
                <h1>Cores</h1>
            </div>";
        print "<table class='table table-hover table-striped table-bordered'>";
            print "<tr>";
            print "<th>ID</th>";
            print "<th>Nome</th>";
            print "<th>Ações</th>";
            print "</tr>";
        while($row = $res->fetch_object()){
            print "<tr>";
            print "<td>".$row->id."</td>";
            print "<td>".$row->name."</td>";
            print"<td>";
            
            	if (in_array($row->id, $vinculados)) {
            		print "<form action=\"?page=save-user-color\" method=\"POST\">
                            <input type=\"hidden\" name=\"acao\" value=\"desvincular\">
                            <input type=\"hidden\" name=\"colorid\" value=\".$row->id.\">
                            <input type=\"hidden\" name=\"userid\" value=\".$userid.\">
                            <button  type=\"submit\" class= 'btn btn-danger'>Desvicular</button>
                       </form>";
				}else{
					print "<form action=\"?page=save-user-color\" method=\"POST\">
                            <input type=\"hidden\" name=\"acao\" value=\"vincular\">
                            <input type=\"hidden\" name=\"colorid\" value=\".$row->id.\">
                            <input type=\"hidden\" name=\"userid\" value=\".$userid.\">
                            <button  type=\"submit\" class= 'btn btn-info'>Vincular</button>
                       </form>";
				}

            print "</td>";
            print "</tr>";
        }
        print "</table>";
        print "<button class= 'btn btn-danger' onclick= \"location.href='?page=list'\"  >Voltar</button>";
    }else{
        print "<h1>Cores</h1>";
        print "<p class='alert alert-danger'>Não encontrou resultados!</p>";
        print"<div class=\"mb-3\">
    <button class= 'btn btn-success' onclick= \"location.href='?page=new-color'\"> Criar </button>
</div>";
    }
?>