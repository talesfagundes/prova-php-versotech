<?php 
	$sql = "SELECT * FROM users";

	$res = $conn->query($sql);

	$qtd = $res->num_rows;

	if($qtd > 0){
		print"<div class=\"mb-3\">
	<h1>Usuários</h1>
	<button class= 'btn btn-success' onclick= \"location.href='?page=new-user'\"> Criar </button>
</div>";
		print "<table class='table table-hover table-striped table-bordered'>";
			print "<tr>";
			print "<th>ID</th>";
			print "<th>Nome</th>";
			print "<th>E-mail</th>";
			print "<th>Cor</th>";
			print "<th>Ações</th>";
			print "</tr>";
		while($row = $res->fetch_object()){
			print "<tr>";
			print "<td>".$row->id."</td>";
			print "<td>".$row->name."</td>";
			print "<td>".$row->email."</td>";
			print "<td></td>";
			print "<td>
					<button onclick=\"location.href='?page=edit-user&id=".$row->id."'\" class= 'btn btn-success'>Editar</button>

					<button onclick=\"location.href='?page=user-color&id=".$row->id."'\" class= 'btn btn-info'>Vincular Cor</button>

					<button onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=save-user&acao=delete-user&id=".$row->id."';}else{false;}\" 
						class= 'btn btn-danger'>Excluir</button>
				  </td>";
			print "</tr>";
		}
		print "</table>";
	}else{
		print "<h1>Usuários</h1>";
		print "<p class='alert alert-danger'>Não encontrou resultados!</p>";
		print"<div class=\"mb-3\">
	<button class= 'btn btn-success' onclick= \"location.href='?page=new-user'\"> Criar </button>
</div>";
	}
?>





<?php 
	$sql = "SELECT * FROM colors";

	$res = $conn->query($sql);

	$qtd = $res->num_rows;

	if($qtd > 0){
		print"<div class=\"mb-3\">
	<h1>Cores</h1>
	<button class= 'btn btn-success' onclick= \"location.href='?page=new-color'\"> Criar </button>
</div>";
		print "<table class='table table-hover table-striped table-bordered'>";
			print "<tr>";
			print "<th>ID</th>";
			print "<th>Nome</th>";
			print "<th>Ações</th>";
			print "</tr>";
		while($row = $res->fetch_object()){
			print "<tr>";
			print "<td>".$row->id."</td>";
			print "<td>".$row->name."</td>";
			print"<td>
					<button onclick=\"location.href='?page=edit-color&id=".$row->id."'\" class= 'btn btn-success'>Editar</button>

					<button onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=save-color&acao=delete-color&id=".$row->id."';}else{false;}\" 
						class= 'btn btn-danger'>Excluir</button>
				  </td>";
			print "</tr>";
		}
		print "</table>";
	}else{
		print "<h1>Cores</h1>";
		print "<p class='alert alert-danger'>Não encontrou resultados!</p>";
		print"<div class=\"mb-3\">
	<button class= 'btn btn-success' onclick= \"location.href='?page=new-color'\"> Criar </button>
</div>";
	}
?>