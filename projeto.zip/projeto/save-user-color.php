<?php

	switch ($_REQUEST["acao"]) {

		case 'vincular':

			$colorid = $_POST['colorid'];
			$userid = $_POST['userid'];

			$sql = "INSERT INTO user_colors (color_id, user_id) VALUES ('{$colorid}', '{$userid}')";

			$res = $conn->query($sql);

			break;
		case 'desvincular':
    $colorid = $_POST['colorid'];
    $userid = $_POST['userid'];

    $sql = "DELETE FROM user_colors WHERE id_user = ".$_REQUEST["userid"];
    
    $res = $conn->query($sql);

    if($res==true){
				print "<script>alert('Desvinculado.');</script>";
				//print "<script>location.href='?page=list';</script>";
			}else{
				print "<script>alert('Não foi possível desvincular');</script>";
				print "<script>location.href='?page=list';</script>";
			}
    break;

			
}
		
	
